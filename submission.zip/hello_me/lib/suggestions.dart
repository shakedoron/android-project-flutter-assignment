import 'package:english_words/english_words.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'userRep.dart';

class Suggestions with ChangeNotifier {
  String _uid;
  Set<WordPair> _saved = Set<WordPair>();
  UserRep _user;

  CollectionReference _suggestionsCollection =
      FirebaseFirestore.instance.collection('suggestions');

  CollectionReference get suggestionsCollection => _suggestionsCollection;

  Set<WordPair> get saved => _saved;

  void update(UserRep user) async {
    _user = user;
    _uid = user.uid;
    if (user.status == Status.Authenticated) {
      var _doc = await _suggestionsCollection.doc(_uid).get();
      if (!_doc.exists)
        await _suggestionsCollection.doc(_uid).set({'suggestions': []});
      savedSuggestions();
    }
  }

  Future addUserData(WordPair suggestion) async {
    return await _suggestionsCollection.doc(_uid).update({
      'suggestions': FieldValue.arrayUnion([
        {
          'first': suggestion.first.toString(),
          'second': suggestion.second.toString()
        }
      ])
    });
  }

  addPair(WordPair pair) {
    _saved.add(pair);
    if (_user.status == Status.Authenticated) addUserData(pair);
  }

  Future removeUserData(WordPair suggestion) async {
    await _suggestionsCollection.doc(_uid).update({
      'suggestions': FieldValue.arrayRemove([
        {
          'first': suggestion.first.toString(),
          'second': suggestion.second.toString()
        }
      ])
    });
  }

  removePair(WordPair pair) {
    _saved.remove(pair);
    if (_user.status == Status.Authenticated) removeUserData(pair);
    notifyListeners();
  }

  Future<Set<WordPair>> getSuggestions() {
    return _suggestionsCollection
        .doc(_uid)
        .get()
        .then((doc) => doc.data())
        .then((data) => data == null
            ? Set<WordPair>()
            : Set<WordPair>.from(data['suggestions']
                .map((arg) => WordPair(arg['first'], arg['second']))));
  }

  savedSuggestions() async {
    if (_uid != null) {
      await _suggestionsCollection.doc(_uid).update({
        'suggestions': FieldValue.arrayUnion(List<dynamic>.from(
            _saved.map((pair) => {'first': pair.first, 'second': pair.second})))
      });
    }
    _saved = await getSuggestions();
    notifyListeners();
  }

  removeSuggestions() {
    _saved.clear();
    notifyListeners();
  }
}
